package mjg.tos

interface Vulcan {
    def soothe()
    boolean decideIfLogical()
}
