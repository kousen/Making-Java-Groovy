package mjg.tos

class LibraryComputer {
	double computePi() { Math.PI }
	String makeTypewriterNoises() { "clickity-clickity-click" }
	
	def start() { "starting computer..." }
	def stop() { "stopping computer..." }
}
