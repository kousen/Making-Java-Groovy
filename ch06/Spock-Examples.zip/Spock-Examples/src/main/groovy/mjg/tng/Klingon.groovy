package mjg.tng

interface Klingon {
    def annoy()
    def fight()
    def howlAtDeath()
}
